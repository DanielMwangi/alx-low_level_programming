# Functions and nested loops
