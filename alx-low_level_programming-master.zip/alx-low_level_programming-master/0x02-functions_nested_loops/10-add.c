#include "main.h"

/**
 * add - add two numbers
 * @i: integer i
 * @j: integer j
 *
 * Return: (Solution)
 */
int add(int i, int j)
{
	return (i + j);
}
