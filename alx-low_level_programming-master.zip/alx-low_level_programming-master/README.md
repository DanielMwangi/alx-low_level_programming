# C PROGRAMMING

<h2><a href=https://alx-intranet.hbtn.io/rltoken/P01aLj9BDfDUOv-y9x82Yw>For information on getting started with C</a></h2>

# Getting started with Betty linter

![Screenshot](./0x00-hello_world/assets/betty.png)

<h2>
    You can access the <a href=https://github.com/holbertonschool/Betty>Repo Betty from here</a>
</h2>

<h2>Task <a href=https://github.com/osala-eng/alx-low_level_programming/tree/master/0x00-hello_world>0x00 Hello world</a></h2>
