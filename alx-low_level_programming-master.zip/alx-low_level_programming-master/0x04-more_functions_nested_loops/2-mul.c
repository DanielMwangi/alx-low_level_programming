#include "main.h"

/**
 * mul - Entry point
 * @a: interger
 * @b: integer
 *
 * Return: a x b
 */
int mul(int a, int b)
{
	return (a * b);
}
