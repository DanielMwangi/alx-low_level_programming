#include "main.h"

/**
 * _strlen - get a string length
 * @s: character pointer
 *
 * Return: integer len
 */
int _strlen(char *s)
{
	return (strlen(s));
}
