/**
 * reset_to_98 - reset the value of a pointer to 98
 * @n: integer pointer
 *
 * Return: void
 */
void reset_to_98(int *n)
{
	*n = 98;
}
