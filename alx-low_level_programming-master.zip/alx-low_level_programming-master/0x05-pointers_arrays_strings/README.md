# pointers_arrays_strings
