#include "main.h"

/**
 * main - Entry point
 * @argc: number of params
 * @argv: array of params
 *
 * Return: Always 0 (Success)
 */

int main(int argc, __noerr char *argv[])
{
	printf("%d\n", argc - 1);

	return (0);
}
