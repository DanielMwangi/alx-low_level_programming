#include "main.h"

/**
 * main - Entry point
 * @argc: number of params
 * @argv: array of params
 *
 * Return: Always 0 (Success)
 */

int main(__noerr int argc, char *argv[])
{
	printf("%s\n", argv[0]);

	return (0);
}
