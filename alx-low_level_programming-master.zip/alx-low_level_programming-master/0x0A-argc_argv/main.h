#if !defined _MAIN_H
#define _MAIN_H

#include <stdio.h>

#include <stdlib.h>

#include <stdbool.h>

#define __noerr __attribute__((unused))

#define END '\0'

int _putchar(char c);


#endif
