# C variables and conditions
