# 0x07-pointers_arrays_strings
